package com.yedam.member;

public class ViewVO {

}
