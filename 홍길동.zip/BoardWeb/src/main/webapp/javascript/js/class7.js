// class7.js
import {
    friend,
    sum,
    getMax
} from './class6.js';

let n1 = 10,
    n2 = 20;
console.log(sum(n1, n2));

console.log(getMax(n1, n2));

console.log(friend.showInfo());